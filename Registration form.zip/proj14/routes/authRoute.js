const express = require('express');
const multer = require('multer');
const {
     showRegisterFormController,
     registerationController,
     showLoginFormController,
     userLoginFormController
 } = require('../controllers/authController');
const router = express.Router();

// multer diskstorage

 const storage  = multer.diskStorage({
    destination:function(req,file,cb){
         cb(null,'public/uploads')
    },
    filename:function(req,file,cb){
        const fname = Date.now() +'-'+ file.originalname 
        cb(null,fname)
    }
})

// multer variable
const upload = multer({storage:storage})

// API
// registerForm
router.get('/',showRegisterFormController);

// register
// http://localhost:5700/register
router.post('/register',upload.single('image') ,registerationController)

// login form
// http://localhost:5700/login-form
router.get('/login-form',showLoginFormController);

// login
// http://localhost:5700/login
router.post('/login',userLoginFormController);



module.exports = {router}