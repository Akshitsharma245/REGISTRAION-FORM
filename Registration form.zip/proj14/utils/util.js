const bcrypt = require('bcrypt')

// hashed password
const hashedPassword = async(userPassword)=>{
    const saltRounds = 11;
     return await bcrypt.hash(userPassword,saltRounds)
    
}

// compare password

// const comparePassword = async(userPassword)=>{
//     return bcrypt.compare()
    
// }
module.exports ={hashedPassword}