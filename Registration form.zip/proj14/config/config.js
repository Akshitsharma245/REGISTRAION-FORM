const mongoose = require('mongoose');
const dotenv = require('dotenv')
// configure dot env
dotenv.config();

const main = async()=>{
   await mongoose.connect(process.env.MONGO_DB)
   console.log('connected to db server...');
}

module.exports = {main}