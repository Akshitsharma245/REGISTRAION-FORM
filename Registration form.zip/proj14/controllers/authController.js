const { userModel } = require("../models/userModel");
const { hashedPassword } = require("../utils/util");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const dotenv = require("dotenv");
// ======= config dotenv ======
dotenv.config();

const showRegisterFormController = async (req, res) => {
  try {
    res.render("home");
  } catch (error) {
    console.log(error);
  }
};

// registeration
const registerationController = async (req, res) => {
  try {
    const hashed = await hashedPassword(req.body.password);
    const user = new userModel({
      name: req.body.name,
      email: req.body.email,
      image: req.file.filename,
      password: hashed,
    });
    user.save();
    res.status(201).render("home", { message: "Registeraton successfull!!" });
  } catch (error) {
    console.log(error);
  }
};

// showLoginFormController
const showLoginFormController = async (req, res) => {
  try {
    res.render("login");
  } catch (error) {
    console.log(error);
  }
};

// userLoginFormController
const userLoginFormController = async (req, res) => {
  try {
    // console.log(req.body.email);

    const user = await userModel.findOne({ email: req.body.email });
    if(!user)
        {
            res.send("You are not registered. Please register First ")
        }
    // compare password
    const match = await bcrypt.compare(req.body.password, user.password);

    if (match) {
      // jwt token
      const token = jwt.sign({ _id: user.id }, process.env.JWT_SECRET_TOKEN, {
        expiresIn: "1d",
      });
      //    console.log(token)
      res.send({ user, token });
    }
    else
    {
        res.send("Invalid credentials.try again!!")
    }

  } catch (error) {
    console.log(error);
  }
};

module.exports = {
  showRegisterFormController,
  registerationController,
  showLoginFormController,
  userLoginFormController,
};
