const express = require("express");
const { main } = require("./config/config");
const { router } = require("./routes/authRoute");
const morgan = require('morgan');
const  bodyParser = require('body-parser');

const app = express();

//=========== db server============
main()
//======================== middleware ==============
app.set("view engine","ejs")
//========== morgan middleware ===================
app.use(morgan('dev'));

// ================ bodyparser ===================
app.use(bodyParser.urlencoded({extended:false}))
// app.use(express.urlencoded({extended:false}))
app.use(bodyParser.json())
// app.use(express.json())

// ========== static files =================
app.use(express.static('public'));

// =========== route middleware ==================

app.use("",router)

app.get("*",(req,res)=>{
        res.send("Page not found")
})


app.listen(5700,()=>console.log("server is running..."))